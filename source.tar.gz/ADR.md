# Project Decision Log (ADR)

## [2026-05-20] Project Initialization
**Status**: Draft
**Context**: Bootstrapping a new workspace with a unified CI/CD pipeline and containerized backend/frontend architectures.
**Decision**: 
- Using `bun` and `elysia` for a high-performance backend.
- Set up as a monorepo workspace for separation of concerns.
- Implemented baseline GitHub Actions pipeline.
**Trade-offs**:
- Bun is fast but still evolving in terms of full Node compatibility, though it is excellent for Elysia.
- We have paused the frontend setup due to architectural conflicts between Svelte and React-based libraries (Mantine/Tremor).

## [2026-05-20] Frontend Framework Selection
**Status**: Decided
**Context**: The initial requested stack was Svelte + Mantine + Tremor.
**Analysis**: Mantine and Tremor are heavily dependent on React (React Context, Hooks, Virtual DOM). Integrating them into Svelte is an anti-pattern.
**Decision**: Pivoted to React (Vite + TypeScript) for the frontend to fully support Mantine and Tremor components out-of-the-box, sacrificing Svelte's raw performance for React's ecosystem compatibility.
**Trade-offs**: 
- Loss of Svelte's zero-Virtual DOM rendering and small bundle size.
- Gain of rapid dashboard development using robust React component libraries (Mantine + Tremor).
