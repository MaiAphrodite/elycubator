import { Button, Group, Title, Container } from '@mantine/core';
import { Card, Text, Metric, Flex, ProgressBar } from '@tremor/react';

function App() {
  return (
    <Container size="lg" py="xl">
      <Title order={1} mb="xl">Incubator Dashboard</Title>
      
      <Group mb="xl">
        <Button variant="filled" color="blue">Calibrate Sensors</Button>
        <Button variant="outline" color="red">Emergency Stop</Button>
      </Group>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="max-w-xs mx-auto">
          <Text>Temperature</Text>
          <Metric>37.5 &deg;C</Metric>
          <Flex className="mt-4">
            <Text>Target: 37.0 &deg;C</Text>
            <Text>101%</Text>
          </Flex>
          <ProgressBar value={101} className="mt-2" color="teal" />
        </Card>

        <Card className="max-w-xs mx-auto">
          <Text>Humidity</Text>
          <Metric>45%</Metric>
          <Flex className="mt-4">
            <Text>Target: 50%</Text>
            <Text>90%</Text>
          </Flex>
          <ProgressBar value={90} className="mt-2" color="blue" />
        </Card>

        <Card className="max-w-xs mx-auto">
          <Text>O2 Levels</Text>
          <Metric>20.9%</Metric>
          <Flex className="mt-4">
            <Text>Target: 21%</Text>
            <Text>99%</Text>
          </Flex>
          <ProgressBar value={99} className="mt-2" color="indigo" />
        </Card>
      </div>
    </Container>
  )
}

export default App
