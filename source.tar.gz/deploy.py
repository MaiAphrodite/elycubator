import paramiko
import os

hostname = '137.184.21.113'
port = 22
username = 'root'
password = 'mAiaphrod1te'

def deploy():
    print(f"Connecting to {hostname}...")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(hostname, port, username, password)
        print("Connected successfully.")
        
        # Upload docker-compose.yml
        print("Uploading docker-compose.yml...")
        sftp = client.open_sftp()
        sftp.put('docker-compose.yml', '/root/docker-compose.yml')
        sftp.close()
        
        # Deploy
        print("Ensuring Docker is installed...")
        stdin, stdout, stderr = client.exec_command('which docker || curl -fsSL https://get.docker.com | sh')
        exit_status = stdout.channel.recv_exit_status()
        
        print("Starting deployment...")
        stdin, stdout, stderr = client.exec_command('cd /root && docker compose pull && docker compose up -d')
        
        # Wait for the command to finish and print output
        exit_status = stdout.channel.recv_exit_status() 
        print("Deployment Output:")
        print(stdout.read().decode())
        
        if exit_status == 0:
            print("Deployment completed successfully.")
        else:
            print("Deployment failed.")
            print("Error:", stderr.read().decode())
            
    except Exception as e:
        print(f"Connection failed: {e}")
    finally:
        client.close()

if __name__ == '__main__':
    deploy()
